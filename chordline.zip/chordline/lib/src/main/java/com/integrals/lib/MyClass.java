package com.integrals.lib;

public class MyClass {
}
